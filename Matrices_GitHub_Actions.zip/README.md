# Matrices V3 - lycee general

Application NumWorks hors ligne pour les cours de seconde, premiere et terminale de la voie generale. Elle contient une base de fiches et quelques outils de calcul; ce n'est pas un chatbot generatif et elle n'utilise pas Internet.

## Matières couvertes

- Mathematiques, avec des notions de seconde actualisees pour la rentree 2026-2027, des notions de specialite, et des commandes de calcul.
- Francais, philosophie, histoire-geographie, HGGSP et HLP.
- Physique-chimie, SVT, SES, SNT et bases de NSI.
- Anglais, espagnol, allemand, italien et arabe.

Les reponses sont courtes et destinees a la revision. Les attendus varient selon le niveau, la specialite et le professeur : verifie toujours les consignes de ton cours. Les informations datees ou susceptibles de changer doivent etre verifiees dans une source officielle.

## Fonctions

- Saisie AZERTY/QWERTY, clavier numerique et suggestions de mots.
- Questions sans accents obligatoires; la casse et la ponctuation finale sont tolerees.
- Calcul scientifique : `2^8`, `sqrt(9)`, `sin(pi/2)`, `racines 1 -3 2`.
- Equation lineaire `ax+b=cx+d` : `eq 2 3 7 0`.
- Pourcentage : `pct 200 15`; taux d'evolution : `evol 80 100`.
- Conversion binaire/hexadecimale, calcul simple de circuit, capitales et quelques traductions.
- Historique local, suggestions liees, styles et themes accessibles depuis le menu.

## Sources du projet

- `src/main.c` : interface, calculateur et moteur de recherche dans la base.
- `src/kb.h` : base C generee; ne pas modifier directement.
- `kb.txt` : fiches de cours et mots-cles.
- `caps.txt` : pays et capitales.
- `tools/gen.py` : controle et generation de `src/kb.h`.
- `src/mini.h`, `src/icon.png`, `src/qr_data.h` : outils et ressources de l'application.

## Regenerer la base

Depuis ce dossier :

```sh
python3 tools/gen.py
```

Le script controle les doublons et la longueur des reponses. Le zip initial ne contient pas `tools/test-template.html`; la generation de la base fonctionne sans ce fichier, mais le testeur HTML n'est pas produit.

## Compiler en `.nwa`

La compilation necessite le projet officiel `epsilon-sample-app-c`, les outils ARM `arm-none-eabi-gcc` et `nwlink`. Voir `INSTALL.md` pour les etapes. La compilation officielle produit `output/app.nwa`, qui peut ensuite etre transfere sur une NumWorks compatible.
