# Compiler et installer sur la NumWorks

Prerequis : une NumWorks recente (modele N0110 ou equivalent) avec le logiciel a jour, un cable USB,
un ordinateur avec Chrome ou Edge. Les applications externes ne fonctionnent pas sur les anciens modeles.
Reference officielle : https://github.com/numworks/epsilon-sample-app-c (son README fait foi si une commande differe).

## 1. Installer les outils
Linux (Debian/Ubuntu, ou WSL sous Windows) :
    sudo apt update
    sudo apt install git make gcc-arm-none-eabi binutils-arm-none-eabi nodejs npm
    sudo npm install -g nwlink
macOS (Homebrew) :
    brew install git node
    brew install --cask gcc-arm-embedded      (ou : brew install arm-none-eabi-gcc)
    npm install -g nwlink
Windows : installer WSL (Ubuntu) puis suivre la partie Linux dans le terminal Ubuntu.

Verifier : `arm-none-eabi-gcc --version`, `node --version`, `nwlink --version` doivent repondre.

## 2. Recuperer le modele d'application officiel
    git clone https://github.com/numworks/epsilon-sample-app-c
    cd epsilon-sample-app-c
    ls src

## 3. Copier le projet
Depuis le dossier du projet, regenerer d'abord la base puis copier dans le dossier `src` du modele :
    python3 tools/gen.py
    main.c, mini.h, kb.h, qr_data.h, icon.png   (ecraser main.c et icon.png)
Si le Makefile du modele liste les fichiers sources, verifier que `src/main.c` y figure.
Le nom de l'application ("Matrices") est defini dans `main.c`.

## 4. Compiler
    make clean
    make build
Le fichier a installer est `output/app.nwa` (le chemin exact est affiche a la fin de la compilation).

Si la compilation echoue :
- `eadk_...` inconnu ou mal ecrit : ouvrir `eadk.h` du modele et corriger le nom dans `main.c`.
- `undefined reference to __aeabi_...` : ajouter `-lgcc` a l'edition de liens dans le Makefile.
- Application trop grosse : retirer des lignes de `kb.txt`, relancer `python3 tools/gen.py`, recompiler.

## 5. Installer sur la calculatrice
1. Ouvrir https://my.numworks.com/apps dans Chrome ou Edge (Firefox et Safari ne gerent pas l'USB web).
2. Brancher la NumWorks en USB. Sur la calculatrice, rester sur l'ecran d'accueil.
3. Choisir le fichier `app.nwa` (bouton d'ajout d'application), puis lancer l'envoi.
4. Autoriser la connexion a la NumWorks dans la fenetre du navigateur, puis attendre la fin du transfert.
5. Debrancher : l'application "Matrices" apparait dans le menu d'accueil.

Sous Windows avec WSL : compiler dans WSL, puis ouvrir `app.nwa` depuis Windows
(`\\wsl$\Ubuntu\home\...`) pour l'envoyer avec le navigateur Windows.

## 6. Verifier
Lancer Matrices, appuyer sur OK, taper `ohm` puis EXE, puis `eq 2 3 7 0` et `2^8`. Si l'ecran reste noir ou si
l'application se ferme, relancer la compilation apres avoir verifie les points de l'etape 4.
