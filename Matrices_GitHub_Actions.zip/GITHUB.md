# Compilation automatique sur GitHub

1. Cree un depot GitHub public ou prive.
2. Importe le contenu de ce ZIP **a la racine** du depot.
3. Ouvre **Actions** > **Compiler Matrices NWA** > **Run workflow**.
4. Si le job reussit, telecharge l'artifact **Matrices-NWA**.
5. Dezippe-le pour obtenir le fichier `.nwa`.

La compilation ne peut pas etre testee dans cet environnement. Si elle echoue, consulte le journal de l'action.
