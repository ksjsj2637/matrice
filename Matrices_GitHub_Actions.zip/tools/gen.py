#!/usr/bin/env python3
# Genere src/kb.h depuis kb.txt et caps.txt; le test HTML est optionnel.
import re, json, unicodedata, os, sys
R = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def asc(s):
    s = s.replace("’", "'")
    return unicodedata.normalize('NFD', s).encode('ascii', 'ignore').decode()
KB = []; bad = 0; seen = set(); duplicates = []
for ln in open(f"{R}/kb.txt", encoding="utf-8"):
    ln = ln.strip()
    if not ln or ln.startswith('#') or '|' not in ln: continue
    k, a = [x.strip() for x in ln.split('|', 1)]
    k, a = asc(k).lower(), asc(a)
    if k in seen: duplicates.append(k)
    seen.add(k)
    if len(a) > 279: print("TROP LONG (%d): %s" % (len(a), a[:50])); bad += 1
    KB.append((k, a))
CAP = []
for ln in open(f"{R}/caps.txt", encoding="utf-8"):
    ln = ln.strip()
    if not ln or ln.startswith('#') or ';' not in ln: continue
    c, v = [x.strip() for x in ln.split(';', 1)]
    disp = asc(c); key = re.sub(r"[-']", ' ', disp.lower())
    CAP.append((key, disp, asc(v)))
wk = sorted({w for k, _ in KB for w in k.split() if len(w) >= 2})
wa = sorted({w for _, a in KB for w in re.findall(r"[a-z]{4,}", a.lower())} - set(wk))
words = wk + wa
esc = lambda s: s.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n').replace('\r', '\\r')
with open(f"{R}/src/kb.h", "w", encoding="utf-8") as f:
    f.write("// Produit par tools/gen.py (kb.txt, caps.txt) - ne pas modifier a la main\n")
    f.write("typedef struct { const char *kw; const char *ans; } Entry;\n")
    f.write("static const Entry KB[] = {\n")
    for k, a in KB: f.write('  {"%s", "%s"},\n' % (esc(k), esc(a)))
    f.write("};\n#define KB_N (sizeof(KB)/sizeof(KB[0]))\n")
    f.write("typedef struct { const char *key, *name, *cap; } Cap;\nstatic const Cap CAP[] = {\n")
    for k, d, v in CAP: f.write('  {"%s", "%s", "%s"},\n' % (esc(k), esc(d), esc(v)))
    f.write("};\n#define CAP_N (sizeof(CAP)/sizeof(CAP[0]))\n")
    f.write("static const char *const WORDS[] = {\n")
    for w in words: f.write('"%s",' % w)
    f.write("\n};\n#define NWORDS (sizeof(WORDS)/sizeof(WORDS[0]))\n#define NWK %d\n" % len(wk))
template = f"{R}/tools/test-template.html"
if os.path.exists(template):
    t = open(template, encoding="utf-8").read()
    t = t.replace("/*KB*/[]", json.dumps(KB, ensure_ascii=False)).replace("/*WORDS*/[]", json.dumps(words)).replace("/*NWK*/0", str(len(wk))).replace("/*CAP*/[]", json.dumps(CAP))
    open(f"{R}/test-ia.html", "w", encoding="utf-8").write(t)
else:
    print("test-template.html absent : test-ia.html non genere")
print("pays:", len(CAP), "entrees:", len(KB), "mots:", len(words), "(mots-cles:", len(wk), ") erreurs:", bad)
if duplicates:
    print("MOTS-CLES EN DOUBLE:", ", ".join(sorted(set(duplicates))))
sys.exit(1 if bad or duplicates else 0)
